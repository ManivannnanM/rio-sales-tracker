@echo off
setlocal enabledelayedexpansion

:: ============================================================
::  RIO PRINT MEDIA ERP v2.0 — Deploy to Render (PRODUCTION)
::  App Name     : RIO PRINT MEDIA ERP v2.0
::  Source files : D:\Rio\Softwares\Merger\Prod\files\Rio-Print-Media
::  GitHub repo  : https://github.com/rioprintmediaa/Rio-Print-Media.git
::  Render URL   : https://rio-print-media.onrender.com
::  MongoDB DB   : RioPrintMedia
:: ============================================================

set FILES_DIR=D:\Rio\Softwares\Merger\Prod\files\Rio-Print-Media
set GITHUB_REPO=https://github.com/rioprintmediaa/Rio-Print-Media.git
set RENDER_URL=https://rio-print-media.onrender.com

echo.
echo =====================================================
echo   RIO PRINT MEDIA ERP v2.0 — Deploy to Render
echo   PRODUCTION
echo =====================================================
echo.

:: ── VERIFY SOURCE FOLDER EXISTS ────────────────────────
if not exist "%FILES_DIR%" (
    echo [ERROR] Source folder not found: %FILES_DIR%
    echo.
    echo Please create the folder and copy these files into it:
    echo   - RIO_PRINT_MEDIA_ERP.html
    echo   - rio_erp_api.py
    echo   - requirements.txt
    echo   - .env
    pause ^& exit /b 1
)

:: ── CHECK GIT INSTALLED ────────────────────────────────
git --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Git is not installed or not in PATH
    echo Download from https://git-scm.com/downloads
    pause ^& exit /b 1
)

:: ── GO TO SOURCE FOLDER ────────────────────────────────
cd /d "%FILES_DIR%"
echo [INFO] Working directory: %CD%
echo.

:: ── INIT REPO IF NOT ALREADY DONE ──────────────────────
if not exist ".git" (
    echo Initializing new git repo...
    git init
    git branch -M main
    git remote add origin %GITHUB_REPO%
    echo [OK] Git repo initialized.
) else (
    git remote remove origin >nul 2>&1
    git remote add origin %GITHUB_REPO%
)

:: ── ONE-TIME CLEANUP ───────────────────────────────────
:: Removes any nested subfolder from git index if it was ever tracked.
git ls-files --error-unmatch "Rio-Print-Media" >nul 2>&1
if %errorlevel% equ 0 (
    echo [ONE-TIME FIX] Removing nested subfolder from git index...
    git rm -r --cached "Rio-Print-Media" >nul 2>&1
    echo [OK] Done.
)

:: ── ADD FILES ──────────────────────────────────────────
echo Adding files...
git add -f RIO_PRINT_MEDIA_ERP.html
git add -f rio_erp_api.py
git add -f requirements.txt
git add -A

:: ── COMMIT ─────────────────────────────────────────────
git diff --cached --quiet
if %errorlevel% equ 0 (
    echo [INFO] No changes detected. Forcing deploy commit...
    git commit --allow-empty -m "Force deploy %date% %time%"
) else (
    git commit -m "Deploy RIO PRINT MEDIA ERP v2.0 — %date% %time%"
)

:: ── PULL THEN PUSH ─────────────────────────────────────
git pull origin main --allow-unrelated-histories --rebase >nul 2>&1
echo Pushing to GitHub...
git push origin main --force

if %errorlevel% equ 0 (
    echo.
    echo =====================================================
    echo   SUCCESS! Pushed to GitHub.
    echo   Render will auto-deploy in 2-3 minutes.
    echo.
    echo   Live URL: %RENDER_URL%
    echo =====================================================
) else (
    echo.
    echo [ERROR] Push failed.
    echo.
    echo Common fixes:
    echo   1. Check GitHub credentials in Windows Credential Manager
    echo   2. Make sure repo exists: %GITHUB_REPO%
    echo   3. Run: git config --global user.email "your@email.com"
    echo          git config --global user.name "Your Name"
)

echo.
pause
endlocal
